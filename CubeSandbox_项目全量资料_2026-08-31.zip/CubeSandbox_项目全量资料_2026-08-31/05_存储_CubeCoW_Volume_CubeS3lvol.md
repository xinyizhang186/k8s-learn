# CubeSandbox 存储：CubeCoW、Volume、CubeS3lvol

## 1. 存储问题分三类

CubeSandbox 中容易混淆的三个概念：

1. **Sandbox rootfs**：每个沙箱自己的运行文件系统。
2. **Snapshot/Template artifact**：用于快速恢复/克隆的状态资产。
3. **Persistent Volume**：生命周期独立于沙箱的数据卷。

三者不能互相替代。

## 2. CubeCoW

`cubecow/` 是 Rust 实现的 Copy-on-Write 存储引擎。

### 核心接口思想

调用方通过统一 `Engine` trait 工作，目前主要后端为 `ReflinkEngine`。

### ReflinkEngine

使用 Linux `FICLONE`：

- 在支持 reflink 的文件系统上共享 extent；
- clone 时先复制文件元数据映射，而非逐字节复制；
- 后续写入才触发 copy-on-write。

官方主部署路径强调 XFS `reflink=1`，这也是为什么 `/data/cubelet` 不能简单放 ext4。

### 特性

- O(1) 语义的元数据 snapshot；
- flat snapshot；
- snapshot of snapshot 仍可 clone；
- volume/snapshot 是普通文件，崩溃后可扫描目录重建索引；
- backend-agnostic Engine API，后续可扩展新后端。

## 3. 为什么 XFS 很关键

在 CubeSandbox 里，XFS 不只是“推荐文件系统”，而是默认高性能路径的基础设施。

若 `/data/cubelet` 为 ext4：

- FICLONE/reflink 语义可能不可用；
- one-click 安装器会做前置检查；
- 模板/snapshot 性能和功能都可能不符合预期。

## 4. Persistent Volume

Volume 是与沙箱独立的持久化资源：

```text
Volume V1
  |       \
mount     mount
  |         |
Sandbox A  Sandbox B
```

官方文档表明 v0.6+ 已引入 Volume framework，并有 Python SDK 支持。

### CSI-like 架构

- Controller side（CubeMaster）：Create / Destroy。
- Node side（Cubelet）：Attach / Detach，返回 host path。
- 再通过 virtiofs/bind mount 进入 MicroVM。

### 能力

- 创建/列出/获取/销毁 Volume；
- 创建沙箱时声明 volume mounts；
- 一个 Volume 可支持并发挂载（取决于后端语义）；
- 支持每沙箱只读挂载扩展；
- driver 可由插件选择；
- 可以实现 NFS、对象存储、分布式文件系统等不同后端插件。

## 5. Snapshot 和 Volume 的差别

| 维度 | Snapshot | Volume |
|---|---|---|
| 目标 | 保存沙箱运行状态 | 保存长期业务数据 |
| 生命周期 | 与 checkpoint/template 体系相关 | 独立于 sandbox |
| 是否包含内存 | 可包含 | 不包含 |
| 典型用途 | rollback/clone/resume | workspace、dataset、cache、产物 |
| 跨沙箱共享 | 通过 clone/restore | 可直接挂载（取决于后端） |

## 6. CubeS3lvol

`CubeS3lvol/` 是 v0.7 相关的 S3-backed block storage 能力。

官方 README 将其描述为：

- 暴露 NVMe/TCP target；
- volume 主数据位于 S3/object storage；
- 本地只保留 WAL/metadata journal；
- 发布构建将 SPDK、DPDK、AWS CRT 等依赖静态整合。

它的价值在于让沙箱状态不再只能依赖某台宿主机本地盘，为跨节点 Pause/Resume 提供远端状态层。

## 7. K8s/集群中的对象存储

当前 K8s 架构把 MinIO 列为默认可部署依赖之一；生产也可以换成外部 S3 兼容存储。Terraform 方案则可以结合云上存储/共享存储设计。

## 8. 存储容量规划

至少要分别估算：

- Template rootfs 大小 × 模板版本数 × 节点副本数；
- 沙箱 writable layer；
- snapshot 数量与脏页量；
- Volume 长期数据；
- 跨节点 S3 snapshot 带宽/容量；
- 构建缓存和镜像缓存。

官方仅要求体验环境 `/data/cubelet >= 50GB`，多模板推荐 200GB+；真实生产通常还需要更大的数据盘与清理策略。

## 9. 运维建议

- 对 snapshot/template 设置 TTL 或 GC。
- 定期检查 XFS 空间、inode 和 reflink 支持。
- 不要只看逻辑沙箱内存规格估算宿主盘占用。
- 对 S3 后端关注 GET/PUT 延迟、带宽和 API 成本。
- Volume 后端要明确一致性、并发挂载和失败恢复语义。
- 模板和 snapshot metadata 与实际 artifact 必须一致，避免孤儿资产。

## 10. 官方来源

- CubeCoW：https://github.com/TencentCloud/CubeSandbox/blob/master/cubecow/README.md
- Volume：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/volume-plugin.md
- CubeS3lvol：https://github.com/TencentCloud/CubeSandbox/blob/master/CubeS3lvol/README.md
- K8s 架构：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/kubernetes/architecture.md
