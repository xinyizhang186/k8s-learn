# CubeSandbox 网络、安全与代理

## 1. 网络分层

```text
外部用户
   |
CubeProxy (入站 L7/端口路由)
   |
Sandbox TAP / CubeVS
   |
MicroVM
   |
CubeVS eBPF (出站 L3/L4)
   |
CubeEgress (可选透明 L7 HTTP/HTTPS)
   |
Internet
```

CubeProxy、CubeVS、CubeEgress 是三个不同层次，不应混为一个“网关”。

## 2. CubeProxy：入站代理

CubeProxy 基于 OpenResty/Lua，把一个公网/内网请求映射到目标 sandbox + exposed port。

常见 URL 模型：

- Host-based：`<port>-<sandbox_id>.<domain>`
- Path-based：`/sandbox/<sandbox_id>/<port>/...`

它需要知道沙箱当前在哪个节点、是否处于 paused 状态，因此会依赖 Redis/CubeMaster/lifecycle-manager 的元数据与恢复机制。

## 3. CubeVS：eBPF L3/L4 数据面

主要能力：

- SNAT/DNAT；
- TCP/UDP/ICMP conntrack；
- 每沙箱策略；
- LPM-trie CIDR matching；
- ARP proxy；
- TAP 流量处理；
- MAC learning（v0.7 增强）。

架构文档强调网络转发/NAT 由 eBPF 完成，减少传统 iptables 数据面依赖。

## 4. 默认隔离理念

安全总览中给出的核心层次：

1. KVM MicroVM 硬件隔离；
2. CubeVS 网络隔离，默认阻断私网/链路本地等敏感地址段；
3. CubeEgress L7 出网控制；
4. 通过请求重写注入 secret，避免直接泄漏给模型；
5. Hypervisor seccomp；
6. CubeAPI 可插拔鉴权。

## 5. CubeEgress：透明出网安全代理

CubeEgress 关注 HTTP/HTTPS 的应用层：

- allow/deny；
- host / port；
- scheme；
- HTTP method；
- path；
- TLS SNI；
- audit；
- credential injection；
- custom port。

### 透明代理链路

官方文档给出的思路是：

1. CubeVS/eBPF 根据目标和策略给流量标记；
2. Host TPROXY 规则把选中流量送到 CubeEgress；
3. HTTP listener / HTTPS listener 做 L7 检查；
4. HTTPS 需要 Cube root CA / 动态 leaf cert 完成 inspection；
5. 符合规则才转发 upstream。

因此应准确表述为：**主要网络数据面是 eBPF；L7 透明代理重定向路径仍使用 TPROXY/iptables 规则。**

## 6. L7 Rule 约束

当前安全代理文档给出的关键限制包括：

- 端口范围 1~65535；
- scheme 为 HTTP/HTTPS；
- host 支持域名或单 IP，L7 host 不是 CIDR；
- 同一 host:port 的规则应保持 scheme 一致；
- 每 host 的 port/scheme 组合有数量上限（当前文档为 8）；
- first-match；
- deny 可直接 403，不访问 upstream；
- 未覆盖的其他端口仍回落到 L3/L4 policy 判断。

这些约束可能随版本演进，生产配置以当前文档/代码为准。

## 7. 凭据注入为什么重要

错误做法：把 GitHub token / 云 API key / SaaS key 放到 Agent prompt 或沙箱环境变量里。

CubeEgress 允许类似：

```text
Agent 只知道访问 api.example.com
       |
       v
CubeEgress 命中策略
       |
Host 侧加入 Authorization / API Key
       |
       v
真实 upstream
```

优势是模型/沙箱本身不必持有真实 secret。

## 8. CubeAPI 鉴权

CubeAPI 默认 **不启用鉴权**。若设置 Auth Callback：

- 优先读取 `Authorization: Bearer ...`；
- 也支持 `X-API-Key`；
- CubeAPI 把凭据、原始 path/method 发送给你的 callback；
- callback 200 放行，其他状态拒绝。

它本质上是“外部鉴权委托”，不是内置完整 IAM。

## 9. WebUI 公开风险

官方 Terraform 安全文档明确提醒：WebUI 本身不是一个可以直接裸露到互联网的完整 IAM 控制台。公网模式下应该通过单独安全组/IP allowlist/VPN 等限制管理面来源。

CubeAPI 若公网开放，则必须配置 Auth Callback，不能依赖默认无鉴权模式。

## 10. 生产网络安全建议

- 管理面、数据库和计算节点均放私网。
- WebUI 仅允许办公网/VPN/堡垒机访问。
- CubeAPI 启用 Auth Callback。
- Proxy 对公网时启用 TLS、限流和每沙箱访问控制。
- 沙箱默认 deny 私网、metadata、link-local 等敏感网段。
- 对 Agent 允许的外网域名使用最小白名单。
- Secret 通过 CubeEgress 注入，不放进模型上下文。
- Audit log 进入集中日志系统并设置脱敏。
- 定期验证 TLS inspection CA 没有泄漏到不该信任的宿主环境。

## 11. 官方来源

- 安全架构：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/architecture/overview.md
- CubeEgress / 安全代理：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/architecture/security-proxy.md
- 鉴权：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/authentication.md
- Terraform 网络加固：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/tencentcloud-terraform-deploy.md
- CubeNet/CubeVS：https://github.com/TencentCloud/CubeSandbox/tree/master/CubeNet
