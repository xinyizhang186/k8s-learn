# CubeSandbox 版本演进、Roadmap、社区与许可证

## 1. Changelog 版本序列

当前仓库 changelog 目录可见：

- v0.1.0
- v0.1.1
- v0.1.2
- v0.2.0
- v0.2.1
- v0.2.2
- v0.3.0
- v0.3.1
- v0.4.0
- v0.5.0
- v0.5.1
- v0.6.0
- v0.7.0

## 2. README 标出的关键里程碑

### v0.3

项目进入公开发布/开源后的基础完善阶段。

### v0.4

继续完善核心沙箱能力与工程化。

### v0.5

README 明确强调：

- Auto Pause / Resume；
- Terraform 一键生产集群；
- ARM64；
- Network Policy 等。

### v0.6

重点包括：

- Kubernetes 支持（Preview）；
- Persistent Volume；
- Template Alias 等开发体验能力。

### v0.7.0 — 2026-08-28

v0.7 changelog 记录 239 commits、57 contributors，并集中增强：

- 跨节点 Pause/Resume，S3 remote snapshot/volume；
- Template/Snapshot 多组件版本兼容；
- 网络子系统重构：network-agent 合入 Cubelet、TAP lifecycle、eBPF policy distribution；
- CubeOps 拆分；
- private HTTP image registry；
- 内置 MinIO 默认 S3 backend；
- node delete；
- dynamic network policy；
- CubeEgress custom ports；
- CubeVS MAC learning；
- CubeProxy management port / gRPC 等。

## 3. 当前 Roadmap

README 当前 Roadmap 关注：

- 跨节点操作性能继续优化；
- 继续补齐 E2B API/SDK 兼容差距；
- sandbox fault recovery；
- resource-aware scheduling。

Roadmap 不是承诺的 release date，应以 issue/changelog 为准。

## 4. 社区

仓库提供：

- GitHub Issues；
- GitHub Discussions；
- Contributing 文档；
- 用户案例/反馈；
- Discord / 微信等社区入口（以 README 当前链接为准）。

## 5. 开源许可证

项目采用 **Apache License 2.0**。

Apache-2.0 通常允许：

- 商业使用；
- 修改；
- 分发；
- 专利授权条款下的使用。

实际再分发需要遵守 LICENSE/NOTICE 等要求，涉及商业产品时仍应让法务检查你的具体组合依赖。

## 6. 重要上游项目

README 对以下项目有特别致谢/依赖关系：

- Cloud Hypervisor
- Kata Containers
- virtiofsd
- containerd-shim-rs
- ttrpc-rust

这能帮助理解其技术谱系：CubeSandbox 是建立在 KVM/RustVMM/containerd/Kata 生态经验之上的定制 Agent Sandbox stack。

## 7. CNCF 生态

README 显示 CubeSandbox 已被列入 CNCF Landscape。它不是等价于“CNCF graduated/incubating project”，只是生态目录收录，二者概念不要混淆。

## 8. 当前活跃度观察

2026-08-31 浏览仓库时：

- 约 11.4k GitHub stars；
- 约 1.1k forks；
- root 页面显示约 875 commits。

这些数字是动态的，仅作为当日观察，不应写成长期固定指标。

## 9. 官方来源

- README：https://github.com/TencentCloud/CubeSandbox/blob/master/README_zh.md
- Changelog：https://github.com/TencentCloud/CubeSandbox/tree/master/docs/zh/changelog
- v0.7.0：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/changelog/v0.7.0.md
- LICENSE：https://github.com/TencentCloud/CubeSandbox/blob/master/LICENSE
- CONTRIBUTING：https://github.com/TencentCloud/CubeSandbox/blob/master/CONTRIBUTING.md
