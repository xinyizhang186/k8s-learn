# envd、自定义镜像与模板构建

## 1. envd 在哪里

CubeSandbox 有两层 guest 内组件容易混淆：

- `cube-agent`：MicroVM 内更底层的 guest agent，负责与 CubeShim/vsock/ttrpc 协作、创建和管理 OCI workload。
- `envd`：运行在沙箱 workload 内的应用侧服务，是 E2B/Cube SDK 进行命令、文件、终端等数据面操作的重要协议端点。

简化链路：

```text
SDK
 | 控制面 create/delete
 v
CubeAPI -> CubeMaster -> Cubelet -> CubeShim -> MicroVM

SDK
 | 数据面 commands/files/code/terminal
 v
CubeProxy -> Sandbox -> envd
                    |
                 user process
```

## 2. envd 默认端口

官方模板文档当前说明：

- envd 默认监听 `49983`；
- `GET :49983/health` 在可用时返回 204；
- SDK 的执行命令、文件操作、终端等能力会访问 envd。

Quick Start 的预构建 code sandbox 模板还暴露了 `49999` 与 `49983`，具体用途要以对应镜像/版本为准。

## 3. 自定义镜像是否必须有 envd

不是绝对必须。

### 需要 envd

如果你希望使用：

- `Sandbox.commands.run()`；
- SDK 文件读写；
- PTY/terminal；
- Code Interpreter 等依赖 envd 的 E2B-compatible 数据面能力；

则自定义镜像需要包含并运行 envd。

### 可以没有 envd

如果你的 Sandbox 只运行自己的 Web/gRPC 服务，客户端只通过 exposed port 访问业务端口，不使用 commands/files/terminal SDK 能力，那么可以不装 envd，直接让模板 probe 指向自己的 HTTP readiness endpoint。

## 4. Template readiness probe

模板不是“进程启动了就立即 snapshot”。Cube 会等待一个 HTTP probe 返回 2xx。

常见 envd 方式：

```bash
--expose-port 49983 \
--probe 49983 \
--probe-path /health
```

这只保证 envd 已 ready，不保证你的其他业务服务也完成预热。

如果你要预热 Jupyter、浏览器、Web app 等，应把 probe 指向真正代表该应用 ready 的 endpoint。

## 5. Probe 同时定义创建后的 ready 语义

当前官方模板文档特别说明：被选为 probe 的端口，在 Sandbox create 返回时应已经能够服务。因此客户端通常不需要 create 后再为该 probe endpoint 额外做平台级 readiness wait。

但：

- 只 `--expose-port`、没有作为 probe 的其他端口不享受同样保证；
- 应用后来自己 crash，平台的“创建时 ready”也不能保证它永远可用。

## 6. 从 OCI 镜像制作 Template

```text
Docker/OCI Image
  |
  | pull + unpack
  v
rootfs
  |
  v
临时 MicroVM 启动
  |
  v
ENTRYPOINT/CMD/envd/业务服务启动
  |
  v
HTTP Probe 2xx
  |
  v
Freeze + memory/filesystem snapshot
  |
  v
Template READY
```

一个 OCI image 可以因为 CPU、内存、网络、启动配置不同，制作成多个不同 Template。

## 7. 从运行中 Sandbox Commit Template

除了 OCI 构建，CubeSandbox 还支持把正在运行的 Sandbox 当前文件系统 + 内存状态提交成新 Template。

典型用途：

1. 先创建开发 Sandbox；
2. 交互式安装依赖、checkout repo、预热缓存；
3. 验证状态正确；
4. `tpl commit` 固化；
5. 后续批量从新 Template 创建。

这适合快速实验；追求严格可复现时，仍建议用 Dockerfile/OCI 构建流程固化依赖。

## 8. 自带镜像建议

- 基础镜像 pin 精确版本，不只用 `latest`。
- envd 也尽量 pin 版本。
- ENTRYPOINT/CMD 不要把 envd 意外覆盖或提前退出。
- 确认健康检查 endpoint 的语义代表“真正 ready”。
- 私有镜像仓库要让所有可能调度到的计算节点都能访问。
- v0.7 支持 private HTTP image registry，但明文 HTTP 仓库本身有安全风险，只应在受控网络使用。
- 多架构环境要构建 multi-arch OCI image；不能假设仓库里的所有官方镜像均已经覆盖 ARM64。

## 9. Quick Start 模板示例

官方当前快速开始使用类似：

```bash
cubemastercli tpl create-from-image \
  --image <sandbox-code-image> \
  --writable-layer-size 1G \
  --expose-port 49999 \
  --expose-port 49983 \
  --probe 49999
```

创建后用 `cubemastercli tpl watch --job-id <job_id>` 观察构建，直到 Template `READY`。

具体镜像地址和 probe 参数应以当前 release/Quick Start 为准，不建议把示例值硬编码到长期生产脚本。

## 10. 官方来源

- Templates：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/templates.md
- 自带镜像接入：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/tutorials/bring-your-own-image.md
- Quick Start：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/quickstart.md
- Code Sandbox example：https://github.com/TencentCloud/CubeSandbox/tree/master/examples/code-sandbox-quickstart
