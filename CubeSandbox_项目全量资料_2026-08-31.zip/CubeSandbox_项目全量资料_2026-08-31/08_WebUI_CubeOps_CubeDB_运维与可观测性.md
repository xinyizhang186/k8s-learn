# CubeSandbox WebUI、CubeOps、CubeDB 与运维面

## 1. WebUI 是什么

WebUI/Dashboard 是面向管理员的人类控制台，不是沙箱内部页面。

单机默认：

```text
http://<control-node-ip>:12088
```

本地前端开发通常是 Vite `:5173`。

注意：`3000` 是 CubeAPI，不是 Dashboard。

## 2. 当前 WebUI 11 个主要页面

| # | 页面 | 用途 |
|---:|---|---|
| 1 | Overview | 沙箱数、CPU/内存、健康节点 |
| 2 | Sandboxes | 列表、创建、暂停、恢复、销毁 |
| 3 | Templates | 模板列表/从 OCI 创建模板 |
| 4 | Nodes | 节点资源、健康、槽位 |
| 5 | Versions | 节点/模板组件版本矩阵 |
| 6 | Network | API gateway / 节点级网络相关管理 |
| 7 | Observability | runtime/沙箱/模板构建状态 |
| 8 | API Keys | Dashboard 请求使用的 API Key |
| 9 | Template Store | 官方预置镜像/模板安装入口 |
| 10 | AgentHub | 管理运行在 CubeSandbox 上的 Agent 实例 |
| 11 | Settings | 主题、语言、集群信息、快捷键 |

## 3. STALE Template

WebUI 中 Template 可能显示 `STALE`。当前文档解释为：

- 节点当前组件版本与 Template 记录不完全一致；
- 并不一定禁止创建；
- 必须确认节点仍有模板所需版本的 kernel/agent/runtime artifact。

这是 v0.7 多版本兼容管理的重要运维概念。

## 4. CubeOps

CubeOps 是从 v0.7 起更加明确独立的 stateful 运维后端。

常见职责：

- 管理员登录/JWT；
- 集群与节点信息；
- AgentHub；
- Template Store；
- Settings/Config；
- 给 WebUI 提供管理 API；
- 代理部分 SDK/管理请求到 CubeMaster。

常见监听：`:3010`。

可见 API group 包括：

- `/api/v1/auth`
- `/api/v1/cluster`
- `/api/v1/agenthub`
- `/api/v1/store`
- `/api/v1/config`
- `/api/v1/sdk/*`

具体以当前路由代码为准。

## 5. CubeAPI 与 CubeOps 的边界

| CubeAPI | CubeOps |
|---|---|
| 面向用户/SDK | 面向管理员/WebUI |
| E2B-compatible REST | 运维管理、JWT、Store/AgentHub |
| 尽量无状态 | 有状态运维后端 |
| Sandbox runtime API | Cluster/operation APIs |

二者会共享 MySQL schema，并同时与 CubeMaster 交互。

## 6. CubeDB

CubeDB 是数据库 migration + DAO 基础包，为 CubeMaster/CubeOps 共用。

工程特性：

- goose v3 migration；
- SHA-256 migration fingerprint；
- MySQL `GET_LOCK` 保证集群多实例迁移互斥；
- GORM/SQL pool；
- health check。

仓库当前已有多批 migration，覆盖 AgentHub、node version、egress、template replica compatibility、artifact、runtime binding、settings JWT secret 等演进内容。

## 7. 为什么需要 fingerprint

如果一份历史 migration 已执行后又被人工修改，多副本服务可能处于无法可靠判断数据库状态的危险状态。因此 CubeDB 对 migration 内容建立 fingerprint，默认阻止“历史迁移被篡改”继续启动。

仓库也提供跳过 fingerprint check 的环境变量用于明确的特殊情况，但生产不应把它当常规开关。

## 8. Redis 运维角色

Redis 主要用于高频共享状态：

- sandbox routing metadata；
- lifecycle event stream；
- CubeProxy registry/heartbeat；
- auto pause/resume coordination；
- 分布式锁/快速状态。

Redis 故障会影响的不是简单 cache miss，而可能影响代理和生命周期自动化。

## 9. lifecycle-manager

独立 lifecycle-manager：

- 消费 Redis sandbox lifecycle stream；
- 发现存活 CubeProxy 副本；
- 将状态/元数据广播到 Proxy；
- 处理 Proxy 触发的 resume callback；
- 使 CubeProxy 可以多副本扩容而不需要静态列表。

## 10. 可观测性建议

官方 WebUI 已提供一部分状态，但生产建议额外建设：

- CubeAPI/CubeMaster/Cubelet/CubeProxy request metrics；
- sandbox create/pause/resume/kill latency；
- scheduler queue depth；
- node slot、CPU、memory、disk；
- XFS 可用空间；
- snapshot/template artifact 数量；
- Redis lag/event stream；
- MySQL connection/migration；
- CubeEgress deny/audit；
- MicroVM crash / shim exit；
- S3 snapshot latency/error rate。

## 11. 安全注意

WebUI 即使有 API Key 页面，也不应被理解为自动拥有完整公网 IAM。官方 Terraform 文档仍建议 WebUI 使用单独安全组/IP 白名单限制来源。

## 12. 官方来源

- WebUI：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/webui.md
- CubeOps：https://github.com/TencentCloud/CubeSandbox/blob/master/CubeOps/README.md
- CubeDB：https://github.com/TencentCloud/CubeSandbox/blob/master/CubeDB/README.md
- lifecycle-manager：https://github.com/TencentCloud/CubeSandbox/blob/master/cube-lifecycle-manager/README.md
