# CubeSandbox 项目全量资料：阅读导航

> 整理基线：TencentCloud/CubeSandbox `master`，核对日期：2026-08-31。当前 README 已进入 **v0.7** 阶段，最新已发布版本为 **v0.7.0（2026-08-28）**。
>
> 说明：这里的“全量资料”指对当前仓库公开文档、主要源码目录、OpenAPI、SDK、部署方案、架构、网络/存储/安全、性能、示例、版本演进和运维注意事项的系统化整理，而不是逐行复制仓库源码。

## 1. 建议阅读顺序

| 文件 | 适合解决的问题 |
|---|---|
| `01_项目概览与核心能力.md` | CubeSandbox 是什么、解决什么问题、核心卖点是什么 |
| `02_系统架构与组件职责.md` | 请求如何从 SDK 一路进入 MicroVM，各组件分别做什么 |
| `03_安装部署_PVM_裸金属_K8s_Terraform.md` | 如何在普通云主机、裸金属、K8s、腾讯云集群中部署 |
| `04_模板_沙箱生命周期_快照_克隆_回滚.md` | Template、Sandbox、Snapshot、Pause/Resume、Clone/Rollback 的关系 |
| `05_存储_CubeCoW_Volume_CubeS3lvol.md` | rootfs、CoW、持久卷、跨节点快照存储怎么实现 |
| `06_网络_CubeVS_CubeProxy_CubeEgress_安全策略.md` | 沙箱入站、出站、eBPF、L7 策略和密钥注入 |
| `07_API_E2B兼容_Python_Go_Node_SDK.md` | API、E2B 兼容方式、Python/Go/Node SDK 能做什么 |
| `08_WebUI_CubeOps_CubeDB_运维与可观测性.md` | Web 控制台、运维后端、数据库迁移、集群管理 |
| `09_源码目录_技术栈_构建测试.md` | 仓库目录、语言技术栈、各源码模块入口 |
| `10_示例项目与典型应用场景.md` | 官方 Examples 能做什么，适合哪些 Agent 场景 |
| `11_性能基准_资源开销_容量规划.md` | 冷启动、并发、快照、内存开销和压测口径 |
| `12_版本演进_Roadmap_社区_许可证.md` | v0.3~v0.7 主要演进、Roadmap、开源信息 |
| `13_常见问题_风险_生产检查清单.md` | 上生产前必须注意什么、常见坑在哪里 |
| `14_envd_自定义镜像与模板构建.md` | 自定义 OCI 镜像如何接入，envd 和 probe 是什么 |
| `15_配置参数_环境变量与端口速查.md` | SDK/部署变量、标签、端口、关键路径速查 |
| `99_官方资料索引.md` | 对应 GitHub 文档和源码入口 |

## 2. 一句话理解 CubeSandbox

CubeSandbox 是面向 AI Agent / 代码执行场景的自托管 MicroVM 沙箱平台：通过 **RustVMM/KVM 提供硬件级隔离**，通过 **预热模板 + 内存/文件系统快照**降低启动成本，通过 **CubeCoW、CubeVS、CubeEgress、CubeProxy**分别解决快照存储、网络隔离、出网安全与入站代理，并提供 **E2B 兼容 API/SDK**、单机/多机部署以及 Web 运维控制台。

## 3. 核心链路速览

```text
Python / Node / Go SDK / E2B SDK
              |
              v
        CubeAPI (REST)
              |
              v
       CubeMaster (调度)
              |
              v
      Cubelet (节点 Agent)
              |
              v
   CubeShim (containerd Shim v2)
              |
              v
 CubeHypervisor (RustVMM + KVM)
              |
              v
        MicroVM Sandbox

数据面：CubeProxy -> Sandbox
出网：Sandbox -> CubeVS(eBPF) -> CubeEgress(L7) -> Internet
存储：OCI -> Template -> CubeCoW/FICLONE -> Snapshot/Clone
共享状态：MySQL + Redis
运维：CubeOps + WebUI
```

## 4. 当前版本需要特别关注的 v0.7 能力

- 跨节点 Pause/Resume：通过 S3 类远端存储传递沙箱状态，当前属于重点新增能力。
- CubeOps 从 CubeAPI 中进一步拆分，形成独立运维后端。
- `cubeopscli` / WebUI 管理能力增强。
- CubeS3lvol 引入面向 S3 的块存储/远程快照能力。
- 网络子系统重构：network-agent 能力并入 Cubelet，TAP 生命周期与策略分发优化。
- 模板与快照携带组件版本兼容信息，以支持多版本节点环境。
- 默认 K8s 形态可包含 MySQL、Redis、MinIO；生产也可替换为外部服务。

## 5. 项目定位边界

CubeSandbox 本身不是“大模型 Agent 框架”。它主要提供 **Agent 执行基础设施**：隔离执行环境、模板、文件系统、进程、网络策略、持久化、生命周期管理、快照和代理入口。LangChain、OpenAI Agents、Claude Code、OpenClaw 等可以作为上层框架/应用接入。

## 6. 主要官方入口

- 仓库：https://github.com/TencentCloud/CubeSandbox
- 中文 README：https://github.com/TencentCloud/CubeSandbox/blob/master/README_zh.md
- 架构：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/architecture/overview.md
- OpenAPI：https://github.com/TencentCloud/CubeSandbox/blob/master/openapi.yml
- Python SDK：https://github.com/TencentCloud/CubeSandbox/tree/master/sdk/python
- 部署文档：https://github.com/TencentCloud/CubeSandbox/tree/master/docs/zh/guide
- 示例：https://github.com/TencentCloud/CubeSandbox/tree/master/examples
- v0.7.0 Changelog：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/changelog/v0.7.0.md
