# CubeSandbox 安装部署：PVM、裸金属、Kubernetes、Terraform

## 1. 部署路线怎么选

| 环境 | 建议路线 | 说明 |
|---|---|---|
| 普通 x86_64 云主机、没有 `/dev/kvm` | PVM | 官方 Quick Start 主路线 |
| x86_64 裸金属/物理机，已有 KVM | Bare Metal | 直接原生 KVM |
| ARM64 裸金属/物理机，已有 KVM | Bare Metal | ARM64 支持；PVM host kernel 不支持 ARM64 |
| 已有 K8s 集群 | Helm/K8s | 当前 README 标为 Preview |
| 腾讯云生产集群 | Terraform + TKE + CVM PVM | 官方提供集群部署器 |
| 本地开发 | dev-env/QEMU 或源码构建 | 更适合开发，不代表生产性能 |

## 2. Quick Start 硬件/系统要求

官方当前文档给出的快速体验要求：

- 架构：x86_64 云主机；PVM 路线不要求云厂商向 VM 暴露 `/dev/kvm`。
- 权限：root。
- 网络：能够拉取发布包与容器镜像。
- glibc：>= 2.31。
- `/data/cubelet`：必须位于支持 reflink 的 XFS（生产建议直接数据盘）。
- 磁盘：至少 50GB；多个模板建议 200GB+。

规格建议：

| 用途 | CPU | 内存 | 磁盘 |
|---|---:|---:|---:|
| 功能体验 | >= 4 核 | >= 8GB | >= 50GB |
| 官方推荐 | 32 核 | 64GB | >= 200GB |

推荐系统：OpenCloudOS 9、TencentOS 4；Ubuntu 20.04/22.04/24.04 有测试记录，但需要额外处理 XFS。

## 3. PVM 路线

### PVM 是什么

PVM（Pagetable-based Virtual Machine）用于在普通云 VM 里提供 CubeSandbox 需要的 KVM 能力。官方说明其核心是基于 KVM、影子页表和共享内存区域实现嵌套虚拟化，不依赖上层云 hypervisor 把 VT-x/AMD-V 直接暴露给 guest。

### 典型步骤

1. 安装 CubeSandbox 提供的 PVM host kernel。
2. 配置 GRUB，重启进入 PVM kernel。
3. `modprobe kvm_pvm`。
4. 检查模块。
5. 运行 one-click installer，并设置 `CUBE_PVM_ENABLE=1`。
6. 访问 CubeAPI / WebUI 验证。

### 关键验证

```bash
uname -r
modprobe kvm_pvm
lsmod | grep kvm
```

### 注意

- PVM host kernel 发布物当前是 x86_64；ARM64 不走这条路线。
- 改宿主内核意味着需要重启；生产环境应先验证内核、驱动和云厂商兼容性。

## 4. 原生 KVM / Bare Metal

如果宿主已有 `/dev/kvm` 且 KVM 正常，可跳过 PVM，直接使用裸金属部署。

适合：

- 物理服务器；
- 云裸金属；
- 已支持 nested virtualization 的 VM；
- ARM64 物理/裸金属环境。

原生 KVM 通常更适合性能基准和对虚拟化链路有严格要求的部署。

## 5. Kubernetes / Helm

### 当前定位

README 对 Kubernetes 支持仍标记为 Preview，但仓库已有完整：

- `architecture.md`
- `install.md`
- `upgrade.md`
- `faq.md`

### 前置要求

- Kubernetes >= 1.24
- Helm >= 3.10
- 可用 StorageClass
- 控制面节点：至少 1，生产建议 3+，>=4C8G
- 计算节点：至少 1，建议 16C32G+

### 节点角色

- `cube.tencent.com/cube-control=true`：控制面。
- `cube.tencent.com/cube-node=true`：计算面。
- 普通云 VM 计算节点可加 `cube.tencent.com/allow-pvm-bootstrap=true` 让 Chart 处理 PVM bootstrap。
- 计算节点推荐使用 taint 隔离其他业务 Pod。

### K8s 组件形态

控制面 Deployment/Service：

- cube-master
- cube-api
- cube-ops
- cube-webui
- cube-proxy
- cube-lifecycle-manager
- MySQL / Redis / MinIO（内置或外部）

计算面 DaemonSet 体系：

- `cube-node-pvm`：PVM host bootstrap（可选）
- `cube-node-bootstrap`
- `cube-node-installer`
- `cube-node`：Cubelet + embedded network runtime + 可选 CubeEgress

### K8s 重要生产坑

Cube 文档特别警告：如果沙箱已运行，而 `cube-node` Pod 的 network namespace 被重建，会导致该节点沙箱网络中断。生产部署应在一开始就正确规划 `hostNetwork` 等网络参数，不要把它当普通无状态 DaemonSet 随意重建。

### XFS

`/data/cubelet` 仍要求 XFS。Chart 的体验模式可以生成 loopback XFS，但生产不应依赖小容量 loopback 文件替代真实数据盘。

## 6. 腾讯云 Terraform 集群部署

官方 Terraform 方案会创建：

- TKE 托管控制面；
- CVM PVM 计算节点；
- 跳板机；
- CLB；
- 云 MySQL 8.0；
- Redis 7.0；
- NAT + EIP；
- 可选 TCR；
- 可选 CFS。

### 默认网络模式

默认 `TENCENTCLOUD_ENABLE_PUBLIC_NETWORK=false`：

- WebUI、CubeAPI、CubeProxy 挂内网 CLB；
- 只允许 VPC 内访问；
- 计算节点无公网 IP；
- 数据库只在 VPC 内。

这比默认直接公网暴露更合理。

### 默认配置不是生产容量

Terraform 文档明确把默认配置定位为 POC/验证：

- 两台 PVM 计算节点；
- TKE worker 也是独立数量；
- 控制面默认单副本；
- 默认无 CFS；
- 默认不创建 TCR。

生产需要重新做 HA、容量和存储设计。

## 7. 端口速览

| 端口 | 组件/用途 |
|---:|---|
| 3000 | CubeAPI（E2B compatible REST） |
| 12088 | 单机 WebUI Dashboard |
| 3010 | CubeOps 运维后端常见监听端口 |
| 80/443 | CubeProxy / WebUI/CLB 对外入口（部署形态有关） |
| 8089 | Terraform 集群中 CubeMaster 内网 CLB（文档默认） |
| 9091 | CubeEgress admin（默认值可配置） |

具体端口以当前配置文件/Chart values 为准。

## 8. 生产部署最低检查

- [ ] `/data/cubelet` 是 XFS/reflink 可用，不是 ext4。
- [ ] CubeAPI 开启外部鉴权或只在可信网络。
- [ ] WebUI 不直接对公网裸露。
- [ ] MySQL、Redis、MinIO/S3 配置持久化和备份。
- [ ] 计算节点不要对公网开放管理端口。
- [ ] Proxy/API 入口通过负载均衡、TLS 和限流保护。
- [ ] 模板和组件版本兼容矩阵已验证。
- [ ] K8s 下提前规划 `cube-node` 网络模型。
- [ ] 有节点下线、沙箱回收、模板副本补齐策略。

## 9. 官方来源

- Quick Start：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/quickstart.md
- PVM：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/pvm-deploy.md
- Bare Metal：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/baremetal-deploy.md
- K8s：https://github.com/TencentCloud/CubeSandbox/tree/master/docs/zh/guide/kubernetes
- Terraform：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/tencentcloud-terraform-deploy.md
