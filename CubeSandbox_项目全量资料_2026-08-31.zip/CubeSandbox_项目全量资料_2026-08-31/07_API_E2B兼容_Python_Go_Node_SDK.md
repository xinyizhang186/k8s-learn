# CubeSandbox API、E2B 兼容与 SDK

## 1. API 入口

仓库根目录提供 `openapi.yml`：

- OpenAPI 3.1；
- API title：CubeAPI；
- E2B-compatible sandbox API；
- base path：`/cubeapi/v1`。

单机默认常见地址：

```text
http://<host>:3000/cubeapi/v1
```

## 2. 核心资源

### Sandbox

公开接口/SDK 涵盖：

- create
- list/get/connect
- update / timeout refresh
- pause/resume
- logs
- network policy update
- delete/kill

### Snapshot

- create snapshot
- list/get snapshot
- rollback
- clone/restore 相关扩展

### Template

- build/start build
- get/list
- alias
- component compatibility metadata

### Volume

Volume API 在单独 Volume 文档和 Cube SDK 中定义，包括 create/list/get/delete 与 mount。根 OpenAPI 的覆盖范围可能随生成版本变化，使用时应优先核对当前 SDK 与服务端实际路由。

## 3. 官方 SDK 目录

仓库当前 `sdk/` 下包括：

- Python
- Go
- Node

另有 E2B SDK 兼容用法。

## 4. Python SDK

安装：

```bash
pip install cubesandbox
```

常用环境变量：

| 变量 | 含义 |
|---|---|
| `CUBE_API_URL` | CubeAPI 管理面 URL，默认可指 `127.0.0.1:3000` |
| `CUBE_TEMPLATE_ID` | 默认创建沙箱使用的 Template ID |
| `CUBE_PROXY_NODE_IP` | 远程数据面访问时直连 CubeProxy 的 IP |
| `CUBE_API_KEY` | 启用鉴权后使用 |
| Proxy HTTP port | 常见默认 80 |
| Sandbox domain | 文档常用 `cube.app` |

### 典型代码执行

```python
from cubesandbox import Sandbox

sb = Sandbox.create()
result = sb.run_code("print('hello')")
print(result)
sb.kill()
```

具体返回对象字段以当前 SDK 为准。

### Commands

可执行 shell/进程命令，适合 Coding Agent、构建工具和测试 harness。

### Filesystem

SDK 提供的文件能力包括：

- write/read
- list
- stat/exists
- mkdir
- rename
- remove
- watch

### Persistent code context

Code Interpreter 场景可保持解释器变量/运行状态，而不是每次执行都是一个全新进程语义。

### Placement

SDK 支持 `distribution_scope` 等放置参数，用于更明确地控制多节点分布策略。

### Network policy

Cube SDK 扩展了网络策略：

- L3/L4 allow_out / deny_out；
- L7 route/rules；
- request host masking / transforms 等 E2B 兼容能力。

### Volume

通过 `Volume.create()` 等方式创建持久卷，并在 `Sandbox.create()` 的 mounts 参数中挂载。

## 5. E2B SDK 迁移

性能文档中仍展示了直接使用 `e2b-code-interpreter` 的方式：

```bash
export E2B_API_URL=http://<cube-api-host>:3000
export E2B_API_KEY=<non-empty-or-real-key>
export CUBE_TEMPLATE_ID=<template-id>
```

然后继续使用 E2B 的 `Sandbox`/Code Interpreter 接口。

注意：

- 本地无鉴权环境过去示例常填任意非空 `E2B_API_KEY`，生产不要误认为这等于真实鉴权。
- Cube 特有 Snapshot/Volume/Placement 等能力通常需要 Cube SDK 或 Cube API 扩展。

## 6. 数据面 URL

控制面 API 与沙箱内服务访问不是同一条链路：

- 控制面：CubeAPI `:3000`。
- 数据面：CubeProxy，常见 `80/443`。
- 远程 SDK 可以通过 `CUBE_PROXY_NODE_IP` 绕过 `*.cube.app` 本地 DNS 假设。

## 7. Auth Header

CubeAPI Auth Callback 支持：

- `Authorization: Bearer <token>`
- `X-API-Key: <key>`

两者同时存在时 Bearer 优先。

## 8. API 设计上的工程含义

CubeSandbox 的 API 分为两类：

1. **兼容面**：让 E2B 客户端能快速迁移。
2. **基础设施扩展面**：Template、Snapshot、Volume、网络、调度等 Cube 自身能力。

因此做二次开发时，不要把“E2B-compatible”理解为内部架构也照搬 E2B；CubeSandbox 的集群、网络、存储都是自己的实现。

## 9. 官方来源

- OpenAPI：https://github.com/TencentCloud/CubeSandbox/blob/master/openapi.yml
- SDK 根目录：https://github.com/TencentCloud/CubeSandbox/tree/master/sdk
- Python SDK：https://github.com/TencentCloud/CubeSandbox/tree/master/sdk/python
- Volume：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/volume-plugin.md
- Authentication：https://github.com/TencentCloud/CubeSandbox/blob/master/docs/zh/guide/authentication.md
